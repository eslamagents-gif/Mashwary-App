package com.mishwary.delivery;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.Window;
import android.view.WindowManager;
import android.content.SharedPreferences;

public class MainActivity extends Activity {
    private WebView webView;
    private class BackupBridge {
        @JavascriptInterface public void saveData(String json) {
            getSharedPreferences(BackupScheduler.PREFS, MODE_PRIVATE).edit().putString(BackupScheduler.DATA, json).apply();
        }
        @JavascriptInterface public boolean backupNow() { return BackupScheduler.writeBackup(MainActivity.this); }
    }
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(android.graphics.Color.rgb(0, 123, 67));
        window.setNavigationBarColor(android.graphics.Color.rgb(245, 248, 243));
        window.getDecorView().setSystemUiVisibility(android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        BackupScheduler.scheduleNext(this);
        webView = new WebView(this);
        webView.setBackgroundColor(android.graphics.Color.rgb(245, 248, 243));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setDatabaseEnabled(true);
        webView.addJavascriptInterface(new BackupBridge(), "AndroidBackup");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        setContentView(webView);
        if (savedInstanceState == null) webView.loadUrl("file:///android_asset/index.html");
        else webView.restoreState(savedInstanceState);
    }
    @Override protected void onSaveInstanceState(Bundle outState) { super.onSaveInstanceState(outState); if (webView != null) webView.saveState(outState); }
    @Override public void onBackPressed() { if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
}
