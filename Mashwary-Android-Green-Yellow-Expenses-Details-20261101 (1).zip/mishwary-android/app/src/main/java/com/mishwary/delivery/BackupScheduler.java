package com.mishwary.delivery;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public final class BackupScheduler {
    private BackupScheduler() {}
    static final String PREFS = "mishwary_backup";
    static final String DATA = "latest_json";

    public static void scheduleNext(Context context) {
        Calendar next = Calendar.getInstance();
        next.set(Calendar.HOUR_OF_DAY, 0);
        next.set(Calendar.MINUTE, 1);
        next.set(Calendar.SECOND, 0);
        next.set(Calendar.MILLISECOND, 0);
        if (!next.after(Calendar.getInstance())) next.add(Calendar.DAY_OF_YEAR, 1);
        Intent intent = new Intent(context, DailyBackupReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(context, 701, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager alarm = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarm != null) alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.getTimeInMillis(), pi);
    }

    public static boolean writeBackup(Context context) {
        try {
            SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            String json = prefs.getString(DATA, null);
            if (json == null || json.trim().isEmpty()) return false;
            File dir = new File(context.getFilesDir(), "backups");
            if (!dir.exists() && !dir.mkdirs()) return false;
            String stamp = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
            File out = new File(dir, "mishwary-backup-" + stamp + ".json");
            try (FileOutputStream stream = new FileOutputStream(out)) {
                stream.write(json.getBytes("UTF-8"));
                stream.flush();
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
