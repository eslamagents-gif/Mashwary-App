package com.mishwary.delivery;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class DailyBackupReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        BackupScheduler.writeBackup(context);
        BackupScheduler.scheduleNext(context);
    }
}
