#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle not found. Open this project in Android Studio, sync Gradle, then choose Build > Build Bundle(s) / APK(s) > Build APK(s)." >&2
  exit 1
fi
gradle assembleDebug
printf '\nAPK output: app/build/outputs/apk/debug/app-debug.apk\n'
