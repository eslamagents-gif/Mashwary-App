@echo off
setlocal
cd /d "%~dp0"
where gradle >nul 2>nul
if errorlevel 1 (
  echo Gradle was not found in PATH.
  echo Open this folder in Android Studio, allow Gradle Sync, then choose:
  echo Build ^> Build Bundle(s) / APK(s) ^> Build APK(s)
  pause
  exit /b 1
)
gradle assembleDebug
if errorlevel 1 exit /b %errorlevel%
echo.
echo APK output: app\build\outputs\apk\debug\app-debug.apk
pause
